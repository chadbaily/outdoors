<!-- $Id: wiki_rebuilddbms.php,v 1.2 2000/08/29 02:42:59 aredridel Exp $ -->
<?php

   echo "Rebuild DBM files called.<p>\n";

?>